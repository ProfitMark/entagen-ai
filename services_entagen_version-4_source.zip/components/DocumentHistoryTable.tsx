
import React, { useEffect, useState, useCallback } from 'react';
import { fetchDocumentHistory, fetchDocumentById } from '../services/documentService';
import { Document, DocumentStatus, ApiError } from '../types';

interface DocumentHistoryTableProps {
  currentUserId: string | null; // New prop
  lastAnalyzedDocumentId: string | null; // Trigger refresh on new analysis
}

const DocumentHistoryTable: React.FC<DocumentHistoryTableProps> = ({ currentUserId, lastAnalyzedDocumentId }) => {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);

  const loadDocuments = useCallback(async () => {
    if (!currentUserId) {
      setDocuments([]); // Clear documents if no user is logged in
      setError('Няма регистриран потребител. Моля, влезте или се регистрирайте, за да видите история.');
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const history = await fetchDocumentHistory(); // user ID is handled within service now
      setDocuments(history);
    } catch (err: any) {
      setError(err.message || 'Неуспешно зареждане на историята на документи.');
    } finally {
      setIsLoading(false);
    }
  }, [currentUserId]); // Reload when currentUserId changes

  useEffect(() => {
    loadDocuments();
  }, [loadDocuments, lastAnalyzedDocumentId]); // Reload when lastAnalyzedDocumentId changes

  const getStatusClasses = (status: DocumentStatus): string => {
    switch (status) {
      case DocumentStatus.COMPLETED:
        return 'bg-green-700 text-green-100';
      case DocumentStatus.PENDING:
        return 'bg-yellow-700 text-yellow-100 animate-pulse';
      case DocumentStatus.FAILED:
        return 'bg-red-700 text-red-100';
      default:
        return 'bg-gray-600 text-gray-100';
    }
  };

  const handleViewDetails = async (documentId: string) => {
    try {
      const doc = await fetchDocumentById(documentId); // user ID is handled within service now
      setSelectedDocument(doc);
    } catch (err: any) {
      setError(err.message || 'Неуспешно зареждане на детайли за документа.');
    }
  };

  const closeModal = () => {
    setSelectedDocument(null);
    setError(null);
  };

  return (
    <div className="bg-gray-800 rounded-lg shadow-xl p-8 overflow-hidden">
      <h2 className="text-3xl font-bold text-indigo-400 mb-6">История на документи</h2>

      <button
        onClick={loadDocuments}
        disabled={!currentUserId || isLoading}
        className={`mb-4 py-2 px-4 rounded-lg transition-colors duration-200 flex items-center
          ${!currentUserId || isLoading ? 'bg-gray-600 text-gray-400 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700 text-white'}`}
      >
        <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004 12s5.686 4.5 16 4.5 16-4.5 16-4.5z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 12V5h-.581m0 0a8.003 8.003 0 00-15.356 2A8.001 8.001 0 0020 12s-5.686-4.5-16-4.5-16 4.5-16 4.5z"></path></svg>
        Опресняване
      </button>

      {isLoading && currentUserId ? (
        <div className="text-center py-10 text-gray-400 flex flex-col items-center">
          <svg className="animate-spin h-10 w-10 text-indigo-400 mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Зареждане на история...
        </div>
      ) : error ? (
        <div className="bg-red-800 text-red-100 p-4 rounded-lg text-center">{error}</div>
      ) : documents.length === 0 && currentUserId ? (
        <div className="text-center py-10 text-gray-400">Няма анализирани документи все още.</div>
      ) : !currentUserId ? (
        <div className="bg-blue-800 text-blue-100 p-4 rounded-lg text-center">Моля, влезте или се регистрирайте, за да видите историята на документи.</div>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-gray-700">
          <table className="min-w-full divide-y divide-gray-700">
            <thead className="bg-gray-700">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Име на документ
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Статус
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Дата/Час
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Действия
                </th>
              </tr>
            </thead>
            <tbody className="bg-gray-800 divide-y divide-gray-700">
              {documents.map((doc) => (
                <tr key={doc.id} className="hover:bg-gray-700 transition-colors duration-150">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-100">{doc.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusClasses(doc.status)}`}>
                      {doc.status === DocumentStatus.COMPLETED && 'Завършен'}
                      {doc.status === DocumentStatus.PENDING && 'В процес'}
                      {doc.status === DocumentStatus.FAILED && 'Неуспешен'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                    {new Date(doc.timestamp).toLocaleString('bg-BG')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      onClick={() => handleViewDetails(doc.id)}
                      className="text-indigo-400 hover:text-indigo-600 transition-colors duration-150"
                      title="Вижте детайли"
                    >
                      Преглед
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Document Details Modal */}
      {selectedDocument && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-lg shadow-2xl p-8 max-w-3xl w-full max-h-[90vh] overflow-y-auto relative">
            <button
              onClick={closeModal}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-100 focus:outline-none"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            <h3 className="text-3xl font-bold text-indigo-400 mb-4">{selectedDocument.name}</h3>
            <p className="text-gray-400 text-sm mb-4">
              <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusClasses(selectedDocument.status)} mr-2`}>
                {selectedDocument.status === DocumentStatus.COMPLETED && 'Завършен'}
                {selectedDocument.status === DocumentStatus.PENDING && 'В процес'}
                {selectedDocument.status === DocumentStatus.FAILED && 'Неуспешен'}
              </span>
              <span className="text-gray-500">
                Дата на анализ: {new Date(selectedDocument.timestamp).toLocaleString('bg-BG')}
              </span>
            </p>
            <div className="mt-6">
              <h4 className="text-xl font-semibold text-gray-200 mb-2">Резюме на анализа:</h4>
              <p className="text-gray-300 leading-relaxed whitespace-pre-wrap">{selectedDocument.summary || 'Няма налично резюме.'}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DocumentHistoryTable;