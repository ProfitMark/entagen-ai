
import React, { useState, ChangeEvent } from 'react';
import { registerUser } from '../services/documentService';
import { UserResponse } from '../types';

interface RegisterLoginCardProps {
  onLoginSuccess: (userId: string) => void;
  onLoginError: (error: string) => void;
}

const RegisterLoginCard: React.FC<RegisterLoginCardProps> = ({ onLoginSuccess, onLoginError }) => {
  const [email, setEmail] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [messageType, setMessageType] = useState<'success' | 'error' | 'info'>('info');

  const handleEmailChange = (event: ChangeEvent<HTMLInputElement>) => {
    setEmail(event.target.value);
    setMessage(null);
  };

  const handleRegisterLogin = async () => {
    if (!email || !email.includes('@')) {
      setMessage('Моля, въведете валиден имейл адрес.');
      setMessageType('error');
      return;
    }

    setIsLoading(true);
    setMessage('Регистрация / Вход...');
    setMessageType('info');

    try {
      const userData: UserResponse = await registerUser(email);
      setMessage(`Успешен вход за: ${userData.email}`);
      setMessageType('success');
      onLoginSuccess(userData.id);
    } catch (error: any) {
      setMessage(error.message || 'Възникна грешка при регистрация/вход.');
      setMessageType('error');
      onLoginError(error.message || 'Неизвестна грешка при вход.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-gray-800 rounded-lg shadow-xl p-8 max-w-lg mx-auto mt-20">
      <h2 className="text-3xl font-bold text-center text-indigo-400 mb-6">Регистрация / Вход</h2>
      <p className="text-gray-300 text-center mb-8">
        Въведете вашия имейл, за да получите достъп до историята на документите си.
      </p>

      <div className="flex flex-col items-center space-y-6">
        <input
          type="email"
          placeholder="Вашият имейл адрес"
          value={email}
          onChange={handleEmailChange}
          className="w-full p-3 rounded-lg bg-gray-700 text-gray-100 border border-gray-600 focus:border-indigo-500 focus:ring focus:ring-indigo-500 focus:ring-opacity-50 transition-all duration-200"
          disabled={isLoading}
        />

        <button
          onClick={handleRegisterLogin}
          disabled={!email.includes('@') || isLoading}
          className={`w-full py-3 px-6 rounded-lg text-lg font-semibold transition-colors duration-200
            ${!email.includes('@') || isLoading
              ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
              : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg'
            }`}
        >
          {isLoading ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Обработка...
            </span>
          ) : (
            'Регистрация / Вход'
          )}
        </button>
      </div>

      {message && (
        <div
          className={`mt-6 p-4 rounded-lg text-center
            ${messageType === 'success' ? 'bg-green-800 text-green-100' : ''}
            ${messageType === 'error' ? 'bg-red-800 text-red-100' : ''}
            ${messageType === 'info' ? 'bg-blue-800 text-blue-100' : ''}
          `}
        >
          {message}
        </div>
      )}
    </div>
  );
};

export default RegisterLoginCard;
