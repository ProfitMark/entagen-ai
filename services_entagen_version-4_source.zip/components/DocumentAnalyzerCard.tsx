
import React, { useState, ChangeEvent } from 'react';
import { analyzeDocument } from '../services/documentService';
import { DocumentStatus } from '../types';

interface DocumentAnalyzerCardProps {
  onDocumentAnalyzed: (documentId: string) => void;
  onAnalysisError: (error: string) => void;
  currentUserId: string | null; // New prop
}

const DocumentAnalyzerCard: React.FC<DocumentAnalyzerCardProps> = ({ onDocumentAnalyzed, onAnalysisError, currentUserId }) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [messageType, setMessageType] = useState<'success' | 'error' | 'info'>('info');

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      setSelectedFile(event.target.files[0]);
      setMessage(null);
    } else {
      setSelectedFile(null);
    }
  };

  const handleAnalyzeClick = async () => {
    if (!currentUserId) {
      setMessage('Моля, влезте или се регистрирайте, за да анализирате документи.');
      setMessageType('error');
      onAnalysisError('Няма регистриран потребител.');
      return;
    }
    if (!selectedFile) {
      setMessage('Моля, изберете файл за анализ.');
      setMessageType('error');
      return;
    }

    setIsLoading(true);
    setMessage('Анализиране на документа...');
    setMessageType('info');

    try {
      const response = await analyzeDocument(selectedFile); // user ID is handled within service now
      if (response.status === DocumentStatus.COMPLETED || response.status === DocumentStatus.PENDING) {
        setMessage(`Документът "${selectedFile.name}" е успешно изпратен за анализ! ID: ${response.documentId}`);
        setMessageType('success');
        onDocumentAnalyzed(response.documentId);
      } else {
        setMessage(`Анализът на документа "${selectedFile.name}" приключи със статус: ${response.status}. Моля, проверете историята за подробности.`);
        setMessageType('info');
      }
    } catch (error: any) {
      setMessage(error.message || 'Възникна непредвидена грешка при анализ.');
      setMessageType('error');
      onAnalysisError(error.message || 'Неизвестна грешка при анализ.');
    } finally {
      setIsLoading(false);
      setSelectedFile(null); // Clear selected file after attempt
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const fileInputRef = React.useRef<HTMLInputElement>(null);

  return (
    <div className="bg-gray-800 rounded-lg shadow-xl p-8 max-w-2xl mx-auto">
      <h2 className="text-3xl font-bold text-center text-indigo-400 mb-6">Анализ на нов документ</h2>
      <p className="text-gray-300 text-center mb-8">
        Качете документ (PDF, DOCX, TXT и др.), за да получите обобщение, ключови изводи и отговори на въпроси чрез Gemini AI.
      </p>

      <div className="flex flex-col items-center space-y-6">
        <label htmlFor="file-upload" className="w-full cursor-pointer">
          <input
            id="file-upload"
            type="file"
            accept=".pdf,.doc,.docx,.txt"
            onChange={handleFileChange}
            ref={fileInputRef}
            className="hidden"
            disabled={!currentUserId || isLoading}
          />
          <div className={`w-full p-6 border-2 border-dashed rounded-lg text-center transition-colors duration-200
            ${!currentUserId || isLoading ? 'border-gray-700 bg-gray-700 cursor-not-allowed' : 'border-gray-600 hover:border-indigo-500'}`}
          >
            <svg className="mx-auto h-12 w-12 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
            </svg>
            <p className="mt-3 text-lg text-gray-400">
              {selectedFile ? selectedFile.name : 'Плъзнете и пуснете файл или щракнете тук за качване'}
            </p>
            <p className="text-sm text-gray-500">(Поддържа .pdf, .doc, .docx, .txt)</p>
          </div>
        </label>

        <button
          onClick={handleAnalyzeClick}
          disabled={!selectedFile || isLoading || !currentUserId}
          className={`w-full py-3 px-6 rounded-lg text-lg font-semibold transition-colors duration-200
            ${!selectedFile || isLoading || !currentUserId
              ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
              : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg'
            }`}
        >
          {isLoading ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Анализиране...
            </span>
          ) : (
            'Стартиране на анализ'
          )}
        </button>
      </div>

      {message && (
        <div
          className={`mt-6 p-4 rounded-lg text-center
            ${messageType === 'success' ? 'bg-green-800 text-green-100' : ''}
            ${messageType === 'error' ? 'bg-red-800 text-red-100' : ''}
            ${messageType === 'info' ? 'bg-blue-800 text-blue-100' : ''}
          `}
        >
          {message}
        </div>
      )}
    </div>
  );
};

export default DocumentAnalyzerCard;