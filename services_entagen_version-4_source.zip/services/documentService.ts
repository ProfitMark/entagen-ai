
import { API_BASE_URL, LOCAL_STORAGE_USER_ID_KEY } from '../constants';
import { AnalyzeDocumentResponse, Document, DocumentStatus, ApiError, UserRegistrationRequest, UserResponse } from '../types';

/**
 * Helper to get user ID from local storage.
 */
const getUserId = (): string | null => {
  return localStorage.getItem(LOCAL_STORAGE_USER_ID_KEY);
};

/**
 * Registers a user or logs them in by email.
 * @param email The user's email address.
 * @returns A promise that resolves with the UserResponse (containing userId/email) or rejects with an error.
 */
export const registerUser = async (email: string): Promise<UserResponse> => {
  try {
    const response = await fetch(`${API_BASE_URL}/users/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email }),
    });

    if (!response.ok) {
      const errorData: ApiError = await response.json();
      throw new Error(errorData.detail || `Грешка при регистрация/вход: ${response.statusText}`);
    }

    const userData: UserResponse = await response.json();
    localStorage.setItem(LOCAL_STORAGE_USER_ID_KEY, userData.id); // Store the returned ID (email)
    return userData;
  } catch (error: any) {
    console.error('Грешка при регистрация/вход на потребител:', error);
    throw new Error(`Възникна грешка при регистрация/вход: ${error.message || 'Неизвестна грешка'}`);
  }
};


/**
 * Uploads a document file for analysis.
 * @param file The file to upload.
 * @returns A promise that resolves with the analysis response or rejects with an error.
 */
export const analyzeDocument = async (file: File): Promise<AnalyzeDocumentResponse> => {
  const userId = getUserId();
  if (!userId) {
    throw new Error('Няма регистриран потребител. Моля, влезте или се регистрирайте.');
  }

  const formData = new FormData();
  formData.append('file', file);

  try {
    const response = await fetch(`${API_BASE_URL}/documents/analyze`, {
      method: 'POST',
      headers: {
        'X-User-Id': userId, // New: Pass user ID in header
      },
      body: formData,
    });

    if (!response.ok) {
      const errorData: ApiError = await response.json();
      throw new Error(errorData.detail || `Грешка при анализ на документа: ${response.statusText}`);
    }

    return await response.json();
  } catch (error: any) {
    console.error('Грешка при изпращане на документ за анализ:', error);
    throw new Error(`Възникна грешка при анализ: ${error.message || 'Неизвестна грешка'}`);
  }
};

/**
 * Fetches the history of analyzed documents for the current user.
 * @returns A promise that resolves with an array of documents or rejects with an error.
 */
export const fetchDocumentHistory = async (): Promise<Document[]> => {
  const userId = getUserId();
  if (!userId) {
    throw new Error('Няма регистриран потребител. Моля, влезте или се регистрирайте.');
  }

  try {
    const response = await fetch(`${API_BASE_URL}/documents/history`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'X-User-Id': userId, // New: Pass user ID in header
      },
    });

    if (!response.ok) {
      const errorData: ApiError = await response.json();
      throw new Error(errorData.detail || `Грешка при зареждане на историята: ${response.statusText}`);
    }

    return await response.json();
  } catch (error: any) {
    console.error('Грешка при зареждане на историята на документи:', error);
    throw new Error(`Възникна грешка при зареждане на история: ${error.message || 'Неизвестна грешка'}`);
  }
};

/**
 * Fetches a specific document by its ID for the current user.
 * @param documentId The ID of the document to fetch.
 * @returns A promise that resolves with the document details or rejects with an error.
 */
export const fetchDocumentById = async (documentId: string): Promise<Document> => {
  const userId = getUserId();
  if (!userId) {
    throw new Error('Няма регистриран потребител. Моля, влезте или се регистрирайте.');
  }

  try {
    const response = await fetch(`${API_BASE_URL}/documents/${documentId}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'X-User-Id': userId, // New: Pass user ID in header
      },
    });

    if (!response.ok) {
      const errorData: ApiError = await response.json();
      throw new Error(errorData.detail || `Грешка при зареждане на документ ${documentId}: ${response.statusText}`);
    }

    return await response.json();
  } catch (error: any) {
    console.error(`Грешка при зареждане на документ ${documentId}:`, error);
    throw new Error(`Възникна грешка при зареждане на документ: ${error.message || 'Неизвестна грешка'}`);
  }
};
