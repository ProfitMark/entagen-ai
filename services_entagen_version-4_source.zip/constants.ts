
export const API_BASE_URL: string = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8000';
export const LOCAL_STORAGE_USER_ID_KEY = 'entagen_user_id'; // New constant
